
import tkinter as tk
from tkinter import PhotoImage

# Function to open a secondary window
def open_secondary_window():
    secondary_window = tk.Toplevel(main_window)
    secondary_window.title("Air Jordan 1 Retro High OG")
    secondary_window.geometry("1000x800")  # Adjust the size as needed
   
    # Load the image file
    image = PhotoImage(file="Js.png4")

    # Create a label widget to display the image
    image_label = tk.Label(secondary_window, image=image)
    image_label.pack()
    image_label.image = image
    image_label.place(relx=0.0, rely=0.0, relwidth=1.0, relheight=1.0)

    # Add a button to close the secondary window
    close_button = tk.Button(secondary_window, text="Close", command=secondary_window.destroy)
    close_button.pack()

def open_third_window():
    third_window = tk.Toplevel(main_window)
    third_window.title("Air Jordan I High G")
    third_window.geometry("1000x800")  # Adjust the size as needed
   
    # Load the image file
    image = PhotoImage(file="blue.png")

    # Create a label widget to display the image
    image_label = tk.Label(third_window, image=image)
    image_label.pack()
    image_label.image = image
    image_label.place(relx=0.0, rely=0.0, relwidth=1.0, relheight=1.0)

    # Add a button to close the third window
    close_button = tk.Button(third_window, text="Close", command=third_window.destroy)
    close_button.pack()

def open_fourth_window():
    fourth_window = tk.Toplevel(main_window)  # Corrected variable name
    fourth_window.title("AIR JORDAN RETRO 4 BASKETBALL SHOES")
    fourth_window.geometry("1800x800")  # Adjust the size as needed
   
    # Load the image file
    image = PhotoImage(file="White.png")

    # Create a label widget to display the image
    image_label = tk.Label(fourth_window, image=image)
    image_label.pack()
    image_label.image = image
    image_label.place(relx=0.0, rely=0.0, relwidth=1.0, relheight=1.0)

    # Add a button to close the fourth window
    close_button = tk.Button(fourth_window, text="Close", command=fourth_window.destroy)
    close_button.pack()

# Function to exit the application
def exit_application():
    main_window.destroy()

# Create the main window
main_window = tk.Tk()
main_window.title("Main Window")
main_window.geometry("500x500")

label1 = tk.Label(main_window, text="Click on the shoe you wish to view.", font=("Times New Roman", 16))
label1.pack()

# Add buttons
button1 = tk.Button(main_window, text="Air Jordan 1 Retro High OG", command=open_secondary_window)
button1.pack()

button2 = tk.Button(main_window, text="Air Jordan I High G", command=open_third_window)
button2.pack()

button3 = tk.Button(main_window, text="AIR JORDAN RETRO 4 BASKETBALL SHOES", command=open_fourth_window)
button3.pack()

button4 = tk.Button(main_window, text="Exit", command=exit_application)
button4.pack()

# Run the application
main_window.mainloop()